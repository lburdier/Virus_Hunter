# Documentation

Bienvenue dans la racine du build Virus Hunter v4.

## Structure
   - Le projet est organisé en plusieurs répertoires :
     - `data/`: Contient le readme sur les jeux de données de Virus Hunter.
     - `doc/`: Contient la documentation du build Virus Hunter.
     - `src/`: Contient les scripts du build Virus Hunter.

## Remarque
   - Assurez-vous de respecter les droits d'auteur et les licences associés aux documents présents dans ce répertoire.

Pour toute question ou clarification, veuillez contacter l'auteur à l'adresse lucas.burdier26@gmail.com.
