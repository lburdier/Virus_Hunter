#--------------------------------------------------
#JVA-01 | BURDIER Lucas | 2024-03-24 | Robot VirusHunter
#--------------------------------------------------

import subprocess
from datetime import datetime

# Liste des noms de scripts à exécuter
scripts = ["A:/SCOLAIRE/FORMATIONS/BTS_SIO/M.VALENTI/virus-hunter/virus-hunter/data/TestOS.py", 
           "A:/SCOLAIRE/FORMATIONS/BTS_SIO/M.VALENTI/virus-hunter/virus-hunter/data/TestVTScanFile.py", 
           "A:/SCOLAIRE/FORMATIONS/BTS_SIO/M.VALENTI/virus-hunter/virus-hunter/data/TestJSON.py", 
           "A:/SCOLAIRE/FORMATIONS/BTS_SIO/M.VALENTI/virus-hunter/virus-hunter/data/virus_detection_log.py",
           "A:/SCOLAIRE/FORMATIONS/BTS_SIO/M.VALENTI/virus-hunter/virus-hunter/data/sms_recap_vonage.py"]

# Heure de début de l'exécution
start_time = datetime.now()

# Exécuter chaque script à la suite
for script in scripts:
    try:
        # Exécuter le script en utilisant subprocess
        subprocess.run(["python", script], check=True)
        print(f"Le script {script} a été exécuté avec succès le {datetime.now()}.")
    except subprocess.CalledProcessError as e:
        print(f"Erreur lors de l'exécution du script {script}: {e}")

# Heure de fin de l'exécution
end_time = datetime.now()

# Afficher le temps total d'exécution
print(f"Temps total d'exécution : {end_time - start_time}")