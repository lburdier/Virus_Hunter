# Documentation

Bienvenue dans le répertoire `src` du build virus_hunter v4. Ce dossier contient des scripts réalisés qui sont liés au build.

/!\ Attention pour des raisons de logistiques, les data ne sont pas fournis, les scripts contenu dans ce répertoire ne sont donc pas exécutable. /!\

## Fichiers

- Script sms_recap_vonage.py # script de SMS récapulatif à l'admin
- Script TestIO.py # script de test pour accès en lecture et écriture
- Script TestJSON.py # script pour convertir les données en JSON puis en objet pyhon
- Script TestOS.py # script pour parcourir les répertoires à scanner
- Script TestVTScanFile.py # script pour analyser les répertoires concernées
- Script virus_detection_log.py # script pour crée un log et mettre en quarantaine les fichiers malveillants
- Script VirusHunter.py (Robot)# script du robot de surveillance
- Script TestPEFile.py script d'analyse certificat
- Script SignatureTestV1
- Script SignatureTestV2

1. **algo.cmd**
   - Ce script batch permet de crée un fichier PML avec Procmon64.exe. 

2. **procmon-shutdown.cmd**
   - Ce script permet de crée lors d'un shutdown, une copy du fichier PML vers le dossier "srv-data-target" trouvable dans le répertoire "\data\srv" du build.

## Utilisation
   - Les scripts présents dans ce répertoire ne nécessite aucuns prérequis, il suffit de les lancer avec une invite de commande CMD.

## Remarque
   - Assurez-vous de respecter les droits d'auteur et les licences associés aux documents présents dans ce répertoire.

Pour toute question ou clarification, veuillez contacter l'auteur à l'adresse lucas.burdier26@gmail.com.
