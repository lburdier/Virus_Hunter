# Documentation

Pour des raisons de logistique, les data du jeu d'essai ne sont pas fournis.


Voici un aperçu des données permettant l'exécution du robot de surveillance VirusHunter.

Contenu du répertoire DATA dans le build original :

- Dossier quarantaine  # permet de stocker les fichiers malveillants
- Dossier srv # utiliser dans le build v.1.0 
- Dossier test-1 # répertoire contenant des fichiers à analyser
- Dossier test-2 # répertoire contenant des fichiers à analyser
- Dossier test-3 # répertoire contenant des fichiers à analyser
- Fichier analyses_results.txt # résultats des analyses par VirusTotal
- Fichier firefox_home-page.PML #Fichier de configuration de Procmon64.exe
- Fichier IOtest-1.txt # fichier de test d'acès en lecture et en écriture
- Fichier IOtest-2.txt # fichier de test d'acès en lecture et en écriture
- Fichier Malicious_files.txt # fichier répertoriant les emplacment des fichiers malveillants
- Fichier virus_detection.log # fichier journalier comportant toutes les informatiosn essentiels sur les virus
- Fichier virus-hunter.cfg # fichier de configuration "3 répertoires inclus"
- Antidote.exe
- WINWORD.exe
- votredomaine.com_cert.pem
- votredomaine.com_key.pem
- Antidote.exe_cert.pem
- Antidote.exe_key.pem
- WINWORD.exe_cert.pem
- WINWORD.exe_key.pem

Pour toute question ou clarification
Veuillez contacter l'auteur à l'adresse lucas.burdier26@gmail.com.