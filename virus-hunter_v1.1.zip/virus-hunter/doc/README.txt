# Documentation

Bienvenue dans le répertoire `doc` du build virus_hunter v.1.1. Ce dossier contient des documents importants liés au projet.

## Fichiers

1. **Windows_Malware_Hunter_Handbook.pdf**
   - Ce fichier PDF fournit un guide détaillé sur la chasse aux logiciels malveillants sous Windows. Consultez ce document pour des informations approfondies sur les méthodes de détection et de prévention.

2. **Windows_Malware_Hunter_Handboo.doc**
   - Ce fichier au format doc fournit un guide détaillé sur la chasse aux logiciels malveillants sous Windows. Consultez ce document pour des informations approfondies sur les méthodes de détection et de prévention.

## Utilisation
   - Les documents présents dans ce répertoire sont une ressource précieuse pour comprendre les aspects techniques et les bonnes pratiques liées au projet. N'hésitez pas à les consulter en cas de besoin.

## Remarque
   - Assurez-vous de respecter les droits d'auteur et les licences associés aux documents présents dans ce répertoire.

Pour toute question ou clarification, veuillez contacter l'auteur à l'adresse lucas.burdier26@gmail.com.
