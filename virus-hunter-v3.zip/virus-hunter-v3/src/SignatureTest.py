#--------------------------------------------------
#JVA-01 | Lucas BURDIER | 2024-18-03 | SignatureTestV1
#--------------------------------------------------
# -*- coding: utf-8 -*-
import os
from OpenSSL import crypto
from datetime import datetime, timedelta

VALIDITY_DAYS = 365

def generate_key_pair():
    key = crypto.PKey()
    key.generate_key(crypto.TYPE_RSA, 2048)
    return key

def create_self_signed_cert(key, domain):
    cert = crypto.X509()
    cert.get_subject().CN = domain
    cert.set_serial_number(1000)
    cert.gmtime_adj_notBefore(0)
    cert.gmtime_adj_notAfter(VALIDITY_DAYS * 24 * 60 * 60)
    cert.set_issuer(cert.get_subject())
    cert.set_pubkey(key)
    cert.sign(key, 'sha256')
    return cert

def verify_cert_signature(cert, ca_cert):
    store = crypto.X509Store()
    store.add_cert(ca_cert)
    ctx = crypto.X509StoreContext(store, cert)
    try:
        ctx.verify_certificate()
        print("La signature du certificat est valide.")
    except crypto.X509StoreContextError as e:
        print("Erreur lors de la vérification de la signature du certificat:", e)

def export_pem_files(key, cert, domain):
    # Spécifier le chemin d'enregistrement
    export_path = r"C:/Users/lukip/OneDrive/Bureau/BTS SIO/M.Valenti/virus-hunter/virus-hunter/data"
    script_path = os.path.dirname(os.path.abspath(__file__))
    export_full_path = os.path.join(script_path, export_path)

    # Exportation de la clé privée au format PEM
    key_file_path = os.path.join(export_full_path, f"{domain}_key.pem")
    with open(key_file_path, "wb") as key_file:
        key_file.write(crypto.dump_privatekey(crypto.FILETYPE_PEM, key))
    print(f"Clé privée exportée vers : {key_file_path}")

    # Exportation du certificat au format PEM
    cert_file_path = os.path.join(export_full_path, f"{domain}_cert.pem")
    with open(cert_file_path, "wb") as cert_file:
        cert_file.write(crypto.dump_certificate(crypto.FILETYPE_PEM, cert))
    print(f"Certificat exporté vers : {cert_file_path}")

def check_cert_validity(cert):
    not_before = cert.get_notBefore().decode("utf-8")
    not_after = cert.get_notAfter().decode("utf-8")
    not_before_date = datetime.strptime(not_before, "%Y%m%d%H%M%SZ")
    not_after_date = datetime.strptime(not_after, "%Y%m%d%H%M%SZ")
    current_date = datetime.now()
    if not_before_date <= current_date <= not_after_date:
        print("Le certificat est valide.")
    else:
        print("Le certificat n'est pas valide.")

def main():
    key = generate_key_pair()
    domain = "votredomaine.com"
    cert = create_self_signed_cert(key, domain)
    check_cert_validity(cert)
    export_pem_files(key, cert, domain)
    verify_cert_signature(cert, cert)

if __name__ == "__main__":
    main()
