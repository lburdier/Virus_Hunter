#--------------------------------------------------
#JVA-01 | Lucas BURDIER | 2024-18-03 | TestPEFile
#--------------------------------------------------
import os
import pefile

def is_file_signed(exe_path):
    try:
        pe = pefile.PE(exe_path)
        return hasattr(pe, 'DIRECTORY_ENTRY_SECURITY')
    except Exception as e:
        print(f"Erreur lors de l'analyse du fichier {exe_path}: {e}")
        return False

def analyze_pe_files(directory_path, output_path):
    with open(output_path, "w") as file:
        for file_name in os.listdir(directory_path):
            if file_name.endswith(".exe"):
                exe_path = os.path.join(directory_path, file_name)
                try:
                    pe = pefile.PE(exe_path)
                    file.write("Chemin du PE : " + exe_path + "\n")
                    file.write("\nNumbers Of Sections :" + str(pe.FILE_HEADER.NumberOfSections))
                    file.write("\nDynamic :" + str(pe.OPTIONAL_HEADER.DllCharacteristics))
                    file.write("\nImage Version :" + str(pe.OPTIONAL_HEADER.MajorImageVersion))
                    file.write("\n\n[*] e_magic value: %s" % hex(pe.DOS_HEADER.e_magic))
                    file.write("\n[*] Signature value: %s" % hex(pe.NT_HEADERS.Signature))
                    
                    file.write("\n\n[*] Listing DOS_HEADER fields...\n")
                    for keys in pe.DOS_HEADER.__keys__:
                        for field in keys:
                            file.write('\t' + field + "\n")

                    file.write("\n")
                    for field in pe.DOS_HEADER.dump():
                        file.write(field + "\n")

                    file.write("\n[*] Number of data directories = %d" %
                            pe.OPTIONAL_HEADER.NumberOfRvaAndSizes + "\n")
                    for data_directory in pe.OPTIONAL_HEADER.DATA_DIRECTORY:
                        file.write('\t' + data_directory.name + "\n")

                    file.write("\n")
                    for data_dir in pe.OPTIONAL_HEADER.DATA_DIRECTORY:
                        file.write(str(data_dir))

                    file.write("\n\n[*] Listing imported DLLs...")
                    for entry in pe.DIRECTORY_ENTRY_IMPORT:
                        file.write('\t' + entry.dll.decode('utf-8') + '\n')

                    file.write("\n")
                    for section in pe.sections:
                        file.write(section.Name.decode('utf-8'))
                        file.write("\n \tVirtual Address: " + hex(section.VirtualAddress))
                        file.write("\n \tVirtual Size: " + hex(section.Misc_VirtualSize))
                        file.write("\n \tRaw Size: " + hex(section.SizeOfRawData))
                    
                    signed = "True" if hasattr(pe, 'DIRECTORY_ENTRY_SECURITY') else "False"
                    file.write(f"\n\nSigned: {signed}\n")
                except Exception as e:
                    print(f"Erreur lors de l'analyse du fichier {exe_path}: {e}")

# Chemin du répertoire contenant les fichiers exécutables à analyser
directory_path = "C:/Users/lukip/OneDrive/Bureau/BTS SIO/M.Valenti/virus-hunter/virus-hunter/data"

# Chemin du fichier de sortie pour enregistrer les résultats
output_path = "C:/Users/lukip/OneDrive/Bureau/BTS SIO/M.Valenti/virus-hunter/virus-hunter/data/resultsTestPEFile.txt"

# Analyser les fichiers exécutables dans le répertoire spécifié et enregistrer les résultats
analyze_pe_files(directory_path, output_path)
