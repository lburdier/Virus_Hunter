# Documentation

Bienvenue dans le répertoire `src` du build virus_hunter v.1. Ce dossier contient des scripts réalisés qui sont liés au build.

## Fichiers

1. **algo.cmd**
   - Ce script batch permet de crée un fichier PML avec Procmon64.exe. 

2. **procmon-shutdown.cmd**
   - Ce script permet de crée lors d'un shutdown, une copy du fichier PML vers le dossier "srv-data-target" trouvable dans le répertoire "\data\srv" du build.

## Utilisation
   - Les scripts présents dans ce répertoire ne nécessite aucuns prérequis, il suffit de les lancer avec une invite de commande CMD.

## Remarque
   - Assurez-vous de respecter les droits d'auteur et les licences associés aux documents présents dans ce répertoire.

Pour toute question ou clarification, veuillez contacter l'auteur à l'adresse lucas.burdier26@gmail.com.
