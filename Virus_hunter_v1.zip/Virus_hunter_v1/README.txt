# Documentation

Bienvenue dans la racine du build Virus Hunter v1.

## Structure
   - Le projet est organisé en plusieurs répertoires :
     - `doc/`: Contient la documentation du build Virus Hunter.
     - `src/`: Contient les scripts du build Virus Hunter.
     - `tools/`: Contient les logiciels de la suite SysInternals`.
     - `data/`: Contient les données nécessaires au projet, notamment le fichier `firefox-home-page.pml`.
     - `data/srv/`: Contient les services liés au projet, avec les sous-répertoires `srv-data-target/` et `srv-tools-target/`.
         - `srv-data-target/`: (Vide par défaut) - prévu pour les données cibles du service.
         - `srv-tools-target/`: Contient les outils nécessaires, tels que `Procmon64.exe` et `firefox-home-page.pmc`.

## Remarque
   - Assurez-vous de respecter les droits d'auteur et les licences associés aux documents présents dans ce répertoire.

Pour toute question ou clarification, veuillez contacter l'auteur à l'adresse lucas.burdier26@gmail.com.
