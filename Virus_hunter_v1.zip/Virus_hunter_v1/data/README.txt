# Documentation

Bienvenue dans le répertoire `data` du build virus_hunter v.1. Ce dossier contient un répertoire "srv" et un fichier au format PML.

## Fichiers

1. **firefox-home-page.pml**
   - Ce fichier est au format PML et n'est ouvrable qu'avec Procmon64.exe. 

## Utilisation
   - Nécesssite Procmon64.exe.

## Remarque
   - Assurez-vous de respecter les droits d'auteur et les licences associés aux documents présents dans ce répertoire.

Pour toute question ou clarification, veuillez contacter l'auteur à l'adresse lucas.burdier26@gmail.com.

Structure : 

build/
|-- README.txt
|-- data/
|   |-- firefox-home-page.pml
|-- srv/
|   |-- srv-data-target/
|       |-- (vide par défaut)
|   |-- srv-tools-target/
|       |-- (Procmon64.exe + firefox-home-page.pmc)
|-- ...

